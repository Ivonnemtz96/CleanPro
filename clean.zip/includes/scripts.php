<!-- External JavaScripts -->
<script src="js/vendor/jquery.js"></script>
<script src="js/vendor/bootstrap.min.js"></script>
<script src="js/vendor/slick.min.js"></script>
<script src="js/vendor/isotope.pkgd.min.js"></script>
<script src="js/vendor/imagesloaded.pkgd.min.js"></script>
<script src="js/vendor/lightbox.min.js"></script>
<script src="js/vendor/jquery.scroll-with-ease.min.js"></script>
<script src="js/vendor/jquery.form.js"></script>
<script src="js/vendor/jquery.validate.min.js"></script>
<script src="js/vendor/moment.js"></script>
<script src="js/vendor/bootstrap-datetimepicker.min.js"></script>
<script src="js/vendor/jquery.waypoints.min.js"></script>
<script src="js/vendor/jquery.countTo.js"></script>
<script src="js/vendor/jquery.print.js"></script>
<script src="js/vendor/jquery.dotdotdot.min.js"></script>
<script src="js/vendor/jquery.doubletaptogo.min.js"></script>
<script src="js/vendor/nouislider.min.js"></script>
<script src="js/vendor/jquery.elevateZoom-3.0.8.min.js"></script>
<script src="js/vendor/jarallax.min.js"></script>
<script src="js/vendor/twentytwenty/jquery.event.move.js"></script>
<script src="js/vendor/twentytwenty/jquery.twentytwenty.js"></script>
<!-- Custom JavaScripts -->
<script src="js/custom.js"></script>
<script src="js/forms.js"></script>
<script src="js/myjs.js"></script>
