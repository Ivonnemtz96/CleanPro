<!DOCTYPE html>
<html lang="es">
<?php
    $title = "Contacto";
    $contacto = "active";
    include("includes/head.php");
?>

<body class="page-index">
    <?php
    include("includes/preloader.php");
    include("includes/header.php");
    include("modules/contact.php");
    include("includes/footer.php");
    include("includes/scripts.php");
    ?>
</body>

</html>