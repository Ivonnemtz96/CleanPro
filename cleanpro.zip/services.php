<!DOCTYPE html>
<html lang="es">
<?php
    $title = "Servicios";
    $servicios = "active";
    include("includes/head.php");
?>

<body class="page-index">
    <?php
    include("includes/preloader.php");
    include("includes/header.php");
    include("modules/services.php");
    include("includes/footer.php");
    include("includes/scripts.php");
    ?>
</body>

</html>