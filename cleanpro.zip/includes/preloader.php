<div class="loading-content">
    <div class="loaded-text" data-text="Clean Pro">
        Clean Pro
    </div>
</div>